ZEXUS - Android app (starter)
1) PC par Android Studio install karo (developer.android.com/studio)
2) File > Open > is 'zexus-android' folder ko chuno, Gradle sync hone do
3) Phone me Settings > About phone > Build number 7 baar tap > Developer options > USB debugging ON
4) Phone USB se jodo, Android Studio me Run (green play) dabao
   Ya: Build > Build APK(s), phir app-debug.apk phone me bhejkar install karo
5) API key: aapki Gemini key app me paste karo
6) Activate dabao, saari permissions Allow karo, bolo: "Zexus, mummy ko call karo"
