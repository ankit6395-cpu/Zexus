package com.zexus.ai

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { go() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("z", 0)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF04050D.toInt())
            setPadding(56, 160, 56, 56)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        root.addView(TextView(this).apply {
            text = "ZEXUS"; textSize = 36f; letterSpacing = 0.3f
            setTextColor(0xFF00E5FF.toInt()); gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "Tumhara AI dost aur assistant"; setTextColor(0xFF7F89B5.toInt())
            gravity = Gravity.CENTER; setPadding(0, 8, 0, 64)
        })
        val key = EditText(this).apply {
            hint = "Gemini API key (AIza...)"
            setText(prefs.getString("key", ""))
            setTextColor(0xFFFFFFFF.toInt()); setHintTextColor(0xFF7F89B5.toInt())
            setSingleLine(true)
        }
        root.addView(key, LinearLayout.LayoutParams(-1, -2))
        val start = Button(this).apply { text = "Activate Zexus" }
        val stop = Button(this).apply { text = "Stop" }
        root.addView(start, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 48 })
        root.addView(stop, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)

        start.setOnClickListener {
            prefs.edit().putString("key", key.text.toString().trim()).apply()
            perms.launch(arrayOf(
                Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS,
                Manifest.permission.CALL_PHONE, Manifest.permission.POST_NOTIFICATIONS
            ))
        }
        stop.setOnClickListener {
            startService(Intent(this, ZexusService::class.java).setAction("STOP"))
        }
    }

    private fun go() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "'Display over other apps' allow karo, phir wapas aakar Activate dabao", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val pm = getSystemService(PowerManager::class.java)
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        }
        ContextCompat.startForegroundService(this, Intent(this, ZexusService::class.java))
        Toast.makeText(this, "Zexus active! 'Zexus' bolkar baat shuru karo", Toast.LENGTH_LONG).show()
    }
}
