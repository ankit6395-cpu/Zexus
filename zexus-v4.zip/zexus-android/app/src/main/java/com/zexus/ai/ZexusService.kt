package com.zexus.ai

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.provider.MediaStore
import android.provider.Settings
import android.telecom.TelecomManager
import android.telephony.SmsManager
import android.view.KeyEvent
import android.os.*
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.speech.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

class ZexusService : Service(), TextToSpeech.OnInitListener {
    private val main = Handler(Looper.getMainLooper())
    private var rec: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    @Volatile private var speaking = false
    private var awakeUntil = 0L
    private val history = mutableListOf<Pair<String, String>>()
    private val wake = Regex("zex|zeks|jex|jeks|zaks|jaks|zecks|jecks|zekh|जेक्स|ज़ेक्स|जैक्स|ज़ैक्स|जेक्श|ज़ेक्श|जेक्सेस|जेक्सिस", RegexOption.IGNORE_CASE)

    private val SYS = """
Tum Zexus ho: user ka dost aur personal assistant, Hindi/Hinglish me baat karte ho (user jis bhasha me bole usi me). 
Dost jaise, bhavnaon wale, chhote aur natural jawab do (1-4 vaakya), emoji/markdown nahi. Padhai (JEE Advanced tak) aur har tarah ke sawalon ka sahi jawab do.
HAMESHA sirf ek JSON object do, aur kuch nahi:
{"say":"jo bolna hai","mood":"calm|happy|sad|excited","action":"none|call|end_call|whatsapp|sms|alarm|timer|open_app|search|youtube|maps|spotify|media|volume_up|volume_down|volume_set|mute|torch_on|torch_off|wifi|airplane|bluetooth","arg":"...","arg2":"..."}
action: call(arg=contact naam ya number); whatsapp(arg=contact naam, arg2=message); alarm(arg=HH:MM 24-ghante, arg2=label); timer(arg=seconds); open_app(arg=app ka naam); search(arg=query); youtube(arg=query); maps(arg=jagah); sms(arg=contact naam, arg2=message); spotify(arg=gaane/artist ka naam, seedha bajega); media(arg=play|pause|next|prev); volume_up/volume_down/mute; volume_set(arg=0-100); torch_on/torch_off; end_call (call kaatna). Wifi/internet, airplane mode, bluetooth ON/OFF Android khud nahi karne deta: action wifi/airplane/bluetooth do (settings khulegi) aur say me bolo ki ek tap karna hoga. Phone band/on karna mumkin nahi, saaf bata do. sms/whatsapp me say me naam aur message bolkar confirm karo.
Agar koi kaam nahi to action "none". Jo kaam karne waale ho wo "say" me chhote me confirm karo.
""".trimIndent()

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("zexus", "Zexus", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "zexus")
            .setContentTitle("Zexus sun raha hai")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        ZLog.add("Zexus shuru ho raha hai...")
        tts = TextToSpeech(this, this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        main.post { listen() }
        return START_STICKY
    }

    override fun onInit(status: Int) {
        val r = tts?.setLanguage(Locale("hi", "IN")) ?: -1
        if (r < 0) { tts?.setLanguage(Locale.getDefault()); ZLog.add("Hindi awaaz nahi mili, default awaaz use ho rahi hai") }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { speaking = false; main.post { listen() } }
            @Deprecated("x") override fun onError(id: String?) { speaking = false; main.post { listen() } }
        })
        ttsReady = true
        speak("Zexus online hai. Bolo, kya karna hai?")
    }

    private fun speak(t: String) {
        rec?.destroy(); rec = null
        if (!ttsReady) { listen(); return }
        speaking = true
        ZLog.setState("speaking")
        tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "z")
    }

    private fun listen() {
        if (speaking || !SpeechRecognizer.isRecognitionAvailable(this)) return
        rec?.destroy()
        rec = SpeechRecognizer.createSpeechRecognizer(this).also { r ->
            r.setRecognitionListener(object : RecognitionListener {
                override fun onResults(b: Bundle?) {
                    val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (t.isNullOrBlank()) main.postDelayed({ listen() }, 500) else handle(t)
                }
                override fun onError(e: Int) { if (e != 6 && e != 7) ZLog.add("Mic error code $e"); if (!speaking) main.postDelayed({ listen() }, 800) }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(b: Bundle?) {}
                override fun onEvent(t: Int, b: Bundle?) {}
            })
            ZLog.setState("listening")
            r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN"))
        }
    }

    private fun handle(text: String) {
        ZLog.add("Suna: $text")
        val now = System.currentTimeMillis()
        val needWake = getSharedPreferences("z", 0).getBoolean("wake", true)
        if (needWake && !wake.containsMatchIn(text) && now > awakeUntil) {
            ZLog.add("(naam 'Zexus' nahi suna, ignore kiya)")
            listen(); return
        }
        val q = text.replace(wake, "").trim()
        awakeUntil = now + 25000
        if (q.isEmpty()) { speak("Haan, bolo"); return }
        ZLog.setState("thinking")
        Thread {
            var err = ""
            val j = try { askClaude(q) } catch (e: Exception) { err = e.message ?: "error"; null }
            main.post {
                if (j == null) {
                    ZLog.mood = "sad"
                    ZLog.add("Error: $err")
                    speak("Gemini se jawab nahi mila. Screen par error dekho.")
                } else {
                    ZLog.mood = j.optString("mood", "calm")
                    ZLog.add("Zexus: " + j.optString("say"))
                    act(j.optString("action", "none"), j.optString("arg"), j.optString("arg2"))
                    speak(j.optString("say", "Theek hai"))
                }
            }
        }.start()
    }

    private fun askClaude(q: String): JSONObject {
        val key = (getSharedPreferences("z", 0).getString("key", "") ?: "").trim()
        if (key.isEmpty()) throw Exception("API key khali hai")
        val contents = JSONArray()
        history.takeLast(10).forEach {
            contents.put(JSONObject().put("role", it.first)
                .put("parts", JSONArray().put(JSONObject().put("text", it.second))))
        }
        contents.put(JSONObject().put("role", "user")
            .put("parts", JSONArray().put(JSONObject().put("text", q))))
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYS))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json").put("maxOutputTokens", 4096))
        var last = "unknown"
        for (model in listOf("gemini-3.8-flash", "gemini-3.6-flash", "gemini-2.5-flash")) {
            try {
                val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                    .openConnection() as HttpURLConnection
                c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 40000
                c.setRequestProperty("content-type", "application/json")
                c.setRequestProperty("x-goog-api-key", key)
                c.outputStream.use { it.write(body.toString().toByteArray()) }
                val code = c.responseCode
                val resp = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
                if (code !in 200..299) {
                    last = "$model HTTP $code: " + resp.replace("\n", " ").take(140)
                    ZLog.add(last)
                    continue
                }
                val text = JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
                val j = JSONObject(text.substring(text.indexOf('{'), text.lastIndexOf('}') + 1))
                history.add("user" to q); history.add("model" to text)
                return j
            } catch (e: Exception) {
                last = "$model: ${e.message}"
                ZLog.add(last)
            }
        }
        throw Exception(last)
    }

    private fun go(i: Intent) {
        try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) {}
    }

    private fun act(a: String, arg: String, arg2: String) {
        when (a) {
            "call" -> number(arg)?.let { go(Intent(Intent.ACTION_CALL, Uri.parse("tel:$it"))) }
            "whatsapp" -> number(arg)?.let {
                var d = it.filter { c -> c.isDigit() }
                if (d.length == 10) d = "91$d"
                go(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$d?text=" + Uri.encode(arg2))))
            }
            "alarm" -> {
                val p = arg.split(":")
                go(Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, p[0].trim().toInt())
                    .putExtra(AlarmClock.EXTRA_MINUTES, p.getOrElse(1) { "0" }.trim().toInt())
                    .putExtra(AlarmClock.EXTRA_MESSAGE, arg2)
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            }
            "timer" -> go(Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, arg.trim().toInt())
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            "open_app" -> {
                val pm = packageManager
                pm.getInstalledApplications(0).firstOrNull {
                    pm.getApplicationLabel(it).toString().contains(arg, true) && pm.getLaunchIntentForPackage(it.packageName) != null
                }?.let { go(pm.getLaunchIntentForPackage(it.packageName)!!) }
            }
            "volume_up" -> repeat(3) { audio().adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI) }
            "volume_down" -> repeat(3) { audio().adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI) }
            "volume_set" -> {
                val a = audio()
                val pct = (arg.filter { it.isDigit() }.toIntOrNull() ?: 50).coerceIn(0, 100)
                a.setStreamVolume(AudioManager.STREAM_MUSIC, a.getStreamMaxVolume(AudioManager.STREAM_MUSIC) * pct / 100, AudioManager.FLAG_SHOW_UI)
            }
            "mute" -> audio().adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
            "torch_on" -> torch(true)
            "torch_off" -> torch(false)
            "sms" -> number(arg)?.let { sendSms(it, arg2) }
            "media" -> mediaKey(arg)
            "spotify" -> playSpotify(arg)
            "end_call" -> { try { getSystemService(TelecomManager::class.java).endCall() } catch (e: Exception) {} }
            "wifi" -> go(Intent(if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY else Settings.ACTION_WIFI_SETTINGS))
            "airplane" -> go(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS))
            "bluetooth" -> go(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
            "search" -> go(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, arg))
            "youtube" -> go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(arg))))
            "maps" -> go(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(arg))))
        }
    }

    private fun audio() = getSystemService(AUDIO_SERVICE) as AudioManager

    private fun torch(on: Boolean) {
        try {
            val cm = getSystemService(CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.first { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            cm.setTorchMode(id, on)
        } catch (e: Exception) {}
    }

    private fun sendSms(to: String, text: String) {
        try {
            @Suppress("DEPRECATION")
            val sm: SmsManager = if (Build.VERSION.SDK_INT >= 31) getSystemService(SmsManager::class.java) else SmsManager.getDefault()
            sm.sendMultipartTextMessage(to, null, sm.divideMessage(text), null, null)
        } catch (e: Exception) {}
    }

    private fun mediaKey(cmd: String) {
        val code = when (cmd.lowercase()) {
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "prev", "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
        }
        val a = audio()
        a.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        a.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun playSpotify(q: String) {
        try {
            startActivity(Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
                .setPackage("com.spotify.music")
                .putExtra(SearchManager.QUERY, q)
                .putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            go(Intent(Intent.ACTION_VIEW, Uri.parse("spotify:search:" + Uri.encode(q))))
        }
    }

    private fun number(name: String): String? {
        if (name.isNotEmpty() && name.all { it.isDigit() || it == '+' }) return name
        return try {
            contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null
            )?.use { if (it.moveToFirst()) it.getString(0) else null }
        } catch (e: Exception) { null }
    }

    override fun onDestroy() {
        rec?.destroy(); tts?.shutdown(); ZLog.setState("idle"); super.onDestroy()
    }
}
