package com.zexus.ai

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.abs
import kotlin.math.sin

class RobotView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val t0 = System.currentTimeMillis()
    private val cyan = Color.parseColor("#00E5FF")
    private val steel = Color.parseColor("#7F89B5")

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat()
        val s = minOf(w, height.toFloat())
        val cx = w / 2f
        val t = (System.currentTimeMillis() - t0) / 1000f
        val state = ZLog.state
        val mood = ZLog.mood
        c.save()
        c.translate(0f, sin(t * 1.6f) * s * 0.012f)

        if (state == "listening") {
            for (i in 0..1) {
                val ph = (t * 0.7f + i * 0.5f) % 1f
                p.style = Paint.Style.STROKE; p.strokeWidth = 3f
                p.color = Color.argb(((1f - ph) * 110f).toInt(), 0, 229, 255)
                c.drawCircle(cx, s * 0.48f, s * (0.34f + ph * 0.16f), p)
            }
        }
        p.style = Paint.Style.STROKE; p.strokeWidth = 4f; p.color = steel
        c.drawLine(cx, s * 0.16f, cx, s * 0.07f, p)
        p.style = Paint.Style.FILL
        p.color = Color.argb((150 + 100 * sin(t * 4f)).toInt(), 0, 229, 255)
        c.drawCircle(cx, s * 0.065f, s * 0.03f, p)

        p.color = if (state == "listening") cyan else Color.parseColor("#807C5CFF")
        c.drawRoundRect(cx - 0.39f * s, s * 0.36f, cx - 0.34f * s, s * 0.58f, 14f, 14f, p)
        c.drawRoundRect(cx + 0.34f * s, s * 0.36f, cx + 0.39f * s, s * 0.58f, 14f, 14f, p)

        val head = RectF(cx - 0.34f * s, s * 0.16f, cx + 0.34f * s, s * 0.80f)
        p.shader = LinearGradient(head.left, head.top, head.right, head.bottom,
            Color.parseColor("#3A4572"), Color.parseColor("#121830"), Shader.TileMode.CLAMP)
        p.style = Paint.Style.FILL
        c.drawRoundRect(head, s * 0.2f, s * 0.2f, p)
        p.shader = null
        p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.color = Color.parseColor("#5B6AA8")
        c.drawRoundRect(head, s * 0.2f, s * 0.2f, p)

        val scr = RectF(head.left + 0.07f * s, head.top + 0.08f * s, head.right - 0.07f * s, head.bottom - 0.08f * s)
        p.style = Paint.Style.FILL; p.color = Color.parseColor("#050816")
        c.drawRoundRect(scr, s * 0.14f, s * 0.14f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = Color.parseColor("#4400E5FF")
        c.drawRoundRect(scr, s * 0.14f, s * 0.14f, p)

        val blink = if ((t % 4.5f) > 4.3f) 0.1f else 1f
        var ry = 0.075f * s * blink
        var ey = 0.43f * s
        var ex = 0f
        if (mood == "happy" || mood == "excited") ry *= 0.7f
        if (mood == "sad") { ry *= 0.85f; ey += 0.015f * s }
        if (state == "thinking") ex = sin(t * 3f) * 0.03f * s
        p.style = Paint.Style.FILL
        for (side in intArrayOf(-1, 1)) {
            val x = cx + side * 0.12f * s + ex
            p.color = Color.argb(60, 0, 229, 255)
            c.drawOval(RectF(x - 0.075f * s, ey - ry * 1.4f, x + 0.075f * s, ey + ry * 1.4f), p)
            p.color = cyan
            c.drawOval(RectF(x - 0.052f * s, ey - ry, x + 0.052f * s, ey + ry), p)
        }

        p.style = Paint.Style.STROKE; p.strokeWidth = 5f; p.strokeCap = Paint.Cap.ROUND; p.color = cyan
        val by = 0.33f * s
        val tilt = if (mood == "sad") 0.035f * s else if (mood == "excited") -0.02f * s else 0f
        c.drawLine(cx - 0.18f * s, by + tilt, cx - 0.07f * s, by - tilt, p)
        c.drawLine(cx + 0.07f * s, by - tilt, cx + 0.18f * s, by + tilt, p)

        if (mood == "happy" || mood == "excited") {
            p.style = Paint.Style.FILL; p.color = Color.argb(110, 255, 78, 205)
            c.drawOval(RectF(cx - 0.25f * s, 0.54f * s, cx - 0.16f * s, 0.585f * s), p)
            c.drawOval(RectF(cx + 0.16f * s, 0.54f * s, cx + 0.25f * s, 0.585f * s), p)
        }

        val my = 0.62f * s
        p.color = cyan
        if (state == "speaking") {
            val o = (0.25f + 0.75f * abs(sin(t * 11f))) * 0.07f * s
            p.style = Paint.Style.FILL
            c.drawOval(RectF(cx - 0.07f * s, my - o / 2f, cx + 0.07f * s, my + o / 2f), p)
        } else {
            val bend = (if (mood == "happy" || mood == "excited") 0.05f else if (mood == "sad") -0.04f else 0.012f) * s
            val path = Path()
            path.moveTo(cx - 0.08f * s, my)
            path.quadTo(cx, my + bend * 2f, cx + 0.08f * s, my)
            p.style = Paint.Style.STROKE
            c.drawPath(path, p)
        }

        p.style = Paint.Style.FILL; p.color = Color.parseColor("#1A2140")
        c.drawRoundRect(RectF(cx - 0.3f * s, 0.84f * s, cx + 0.3f * s, 1.15f * s), s * 0.12f, s * 0.12f, p)
        p.color = Color.argb((160 + 90 * sin(t * 3f)).toInt(), 0, 229, 255)
        c.drawCircle(cx, 0.93f * s, 0.028f * s, p)
        c.restore()
        postInvalidateOnAnimation()
    }
}
