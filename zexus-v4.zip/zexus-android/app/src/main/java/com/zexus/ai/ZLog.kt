package com.zexus.ai

object ZLog {
    val lines = ArrayList<String>()
    @Volatile var listener: (() -> Unit)? = null
    @Volatile var state = "idle"
    @Volatile var mood = "calm"
    fun add(s: String) {
        synchronized(lines) { lines.add(s); while (lines.size > 40) lines.removeAt(0) }
        listener?.invoke()
    }
    fun setState(s: String) { state = s; listener?.invoke() }
    fun text(): String = synchronized(lines) { lines.joinToString("\n") }
}
