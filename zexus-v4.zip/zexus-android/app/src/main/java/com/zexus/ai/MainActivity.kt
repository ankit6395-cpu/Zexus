package com.zexus.ai

import android.Manifest
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { go() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun bg(color: Int, r: Int, stroke: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(r).toFloat()
        if (stroke != 0) g.setStroke(dp(1), stroke)
        return g
    }

    private fun bubble(text: String, mine: Boolean): TextView {
        val v = TextView(this)
        v.text = text
        v.textSize = 14f
        v.setTextColor(Color.WHITE)
        v.setPadding(dp(12), dp(8), dp(12), dp(8))
        v.background = if (mine) bg(Color.parseColor("#5B4BFF"), 16)
        else bg(Color.parseColor("#1AFFFFFF"), 16, Color.parseColor("#26FFFFFF"))
        val lp = LinearLayout.LayoutParams(-2, -2)
        lp.gravity = if (mine) Gravity.END else Gravity.START
        lp.topMargin = dp(6)
        v.layoutParams = lp
        return v
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("z", 0)
        val cyan = Color.parseColor("#00E5FF")

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.parseColor("#0C1A3A"), Color.parseColor("#04050D")))
        root.setPadding(dp(16), dp(40), dp(16), dp(14))

        val title = TextView(this)
        title.text = "ZEXUS"
        title.textSize = 22f
        title.letterSpacing = 0.4f
        title.setTextColor(cyan)
        title.gravity = Gravity.CENTER
        title.typeface = Typeface.DEFAULT_BOLD
        root.addView(title, LinearLayout.LayoutParams(-1, -2))

        val robot = RobotView(this)
        val rlp = LinearLayout.LayoutParams(dp(210), dp(210))
        rlp.gravity = Gravity.CENTER_HORIZONTAL
        rlp.topMargin = dp(6)
        root.addView(robot, rlp)

        val status = TextView(this)
        status.textSize = 13f
        status.setTextColor(Color.parseColor("#7F89B5"))
        status.gravity = Gravity.CENTER
        val slp = LinearLayout.LayoutParams(-1, -2)
        slp.bottomMargin = dp(8)
        root.addView(status, slp)

        val chat = LinearLayout(this)
        chat.orientation = LinearLayout.VERTICAL
        val scroll = ScrollView(this)
        scroll.addView(chat)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = bg(Color.parseColor("#14FFFFFF"), 18, Color.parseColor("#1FFFFFFF"))
        card.setPadding(dp(12), dp(12), dp(12), dp(12))

        val key = EditText(this)
        key.hint = "Gemini API key paste karo"
        key.setText(prefs.getString("key", ""))
        key.setSingleLine(true)
        key.setTextColor(Color.WHITE)
        key.setHintTextColor(Color.parseColor("#7F89B5"))
        key.background = bg(Color.parseColor("#1AFFFFFF"), 12)
        key.setPadding(dp(12), dp(10), dp(12), dp(10))
        card.addView(key, LinearLayout.LayoutParams(-1, -2))

        val wakeBox = CheckBox(this)
        wakeBox.text = "Sirf 'Zexus' bolne par jawab do"
        wakeBox.setTextColor(Color.WHITE)
        wakeBox.isChecked = prefs.getBoolean("wake", true)
        wakeBox.setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("wake", c).apply() }
        card.addView(wakeBox, LinearLayout.LayoutParams(-1, -2))

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val start = Button(this)
        start.text = "Activate Zexus"
        start.isAllCaps = false
        start.setTextColor(Color.parseColor("#002B36"))
        start.typeface = Typeface.DEFAULT_BOLD
        start.background = bg(cyan, 14)
        val stop = Button(this)
        stop.text = "Stop"
        stop.isAllCaps = false
        stop.setTextColor(Color.WHITE)
        stop.background = bg(Color.parseColor("#33FFFFFF"), 14)
        val l1 = LinearLayout.LayoutParams(0, -2, 2f)
        l1.rightMargin = dp(8)
        row.addView(start, l1)
        row.addView(stop, LinearLayout.LayoutParams(0, -2, 1f))
        card.addView(row, LinearLayout.LayoutParams(-1, -2))

        val clp = LinearLayout.LayoutParams(-1, -2)
        clp.topMargin = dp(8)
        root.addView(card, clp)

        fun refresh() {
            chat.removeAllViews()
            for (l in ZLog.text().split("\n")) {
                if (l.isBlank()) continue
                if (l.startsWith("Suna: ")) chat.addView(bubble(l.removePrefix("Suna: "), true))
                else if (l.startsWith("Zexus: ")) chat.addView(bubble(l.removePrefix("Zexus: "), false))
                else {
                    val n = TextView(this@MainActivity)
                    n.text = l
                    n.textSize = 11f
                    val bad = l.contains("rror") || l.contains("HTTP")
                    n.setTextColor(Color.parseColor(if (bad) "#FF8A9A" else "#7F89B5"))
                    n.setPadding(0, dp(4), 0, 0)
                    chat.addView(n)
                }
            }
            status.text = when (ZLog.state) {
                "listening" -> "Sun raha hoon..."
                "thinking" -> "Soch raha hoon..."
                "speaking" -> "Bol raha hoon..."
                else -> "Zexus band hai. Activate dabao"
            }
            scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        }
        ZLog.listener = { runOnUiThread { refresh() } }

        start.setOnClickListener {
            prefs.edit().putString("key", key.text.toString().trim()).apply()
            perms.launch(arrayOf(
                Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS,
                Manifest.permission.CALL_PHONE, Manifest.permission.POST_NOTIFICATIONS,
                Manifest.permission.SEND_SMS, Manifest.permission.ANSWER_PHONE_CALLS
            ))
        }
        stop.setOnClickListener {
            startService(Intent(this, ZexusService::class.java).setAction("STOP"))
        }
        setContentView(root)
        refresh()
    }

    private fun go() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "'Display over other apps' allow karo, phir wapas aakar Activate dabao", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val pm = getSystemService(PowerManager::class.java)
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        }
        ContextCompat.startForegroundService(this, Intent(this, ZexusService::class.java))
    }
}
